import { expect } from '@jest/globals';

describe('Testing Job Template', () => {
  test('GET all orders', async () => {
    expect(1).toBe(1);
  });
});
