/**
 * Configure Middleware. Example only. Adapt on your own
 */
export const createHttpMiddlewareOptions = (region) => ({
  host: `https://api.${region}.commercetools.com`,
});
