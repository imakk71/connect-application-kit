module.exports = {
  displayName: 'Tests Javascript Application - Job',
  moduleDirectories: ['node_modules', 'src'],
  testMatch: ['**/?(*.)+(spec|test).[j]s?(x)'],
  testEnvironment: 'node',
};
