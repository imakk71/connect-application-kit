import { expect } from '@jest/globals';

//@todo: test this with msw (see typescipt job)
//  make msw a shared package
describe('Testing Event Controller', () => {
  test('POST `/event` route', async () => {
    expect(1).toBe(1);
  });
});
