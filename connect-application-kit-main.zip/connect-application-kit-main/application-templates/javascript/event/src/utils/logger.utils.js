import { createApplicationLogger } from '@commercetools-backend/loggers';

export const logger = createApplicationLogger();
