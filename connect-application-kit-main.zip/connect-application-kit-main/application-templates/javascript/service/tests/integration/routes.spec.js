import { expect } from '@jest/globals';

//@todo: implement tests (use msw in shared package)
describe('Testing Cart Controller', () => {
  test('POST `/service` route', async () => {
    expect(1).toBe(1);
  });
});
