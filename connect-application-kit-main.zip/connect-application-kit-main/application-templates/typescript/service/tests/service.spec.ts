import { describe, expect, test } from '@jest/globals';

describe('Testing Cart Controller', () => {
  test('POST `/service` route', async () => {
    expect(1).toBe(1);
  });
});
