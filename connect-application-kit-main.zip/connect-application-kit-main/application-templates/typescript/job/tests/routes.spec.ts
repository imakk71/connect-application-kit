import { describe, expect, test } from '@jest/globals';

describe('Testing Job', () => {
  test('Mock Job testing', async () => {
    expect(1).toBe(1);
  });
});
