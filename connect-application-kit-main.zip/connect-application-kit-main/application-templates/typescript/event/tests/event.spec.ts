import { describe, expect, test } from '@jest/globals';

describe('Testing Event Controller', () => {
  test('POST `/event` route', async () => {
    expect(1).toBe(1);
  });
});
