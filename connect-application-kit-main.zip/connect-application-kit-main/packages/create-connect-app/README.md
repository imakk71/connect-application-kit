@commercetools-connect/create-connect-app

Check out the documentation for more information.

[Documentation](https://github.com/commercetools/connect-application-kit#readme).
